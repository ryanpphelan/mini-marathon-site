26.2 STEP MINI MARATHON - PRESS KIT

Thanks for covering the 26.2 Step Mini Marathon. This kit contains:

  - Current press release (2026, our 10th Annual)
  - One-page fact sheet
  - Logo (full and oval versions)
  - Founder photo (Denise Ibsen Cole)
  - "Past releases" folder with our 2024 and 2025 announcements, for reference

For interviews, higher-resolution or vector logos, or founder availability:
  contact@262minimarathon.com
  262minimarathon.com

The 26.2 Step Mini Marathon is an Omaha-based 501(c)(3) nonprofit (in formation)
raising awareness of hereditary cancer risk and removing barriers to education
and genetic testing. Founded in 2016 by Denise Ibsen Cole.
