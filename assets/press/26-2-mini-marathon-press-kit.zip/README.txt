26.2 STEP MINI MARATHON — PRESS KIT
====================================

Contents
- 26-2-mini-marathon-fact-sheet.pdf  : one-page fact sheet (mission, facts, events, founder bio)
- 26-2-mini-marathon-logo.jpg        : organization logo
- denise-ibsen-cole.jpg              : founder photo (Denise Ibsen Cole)

Boilerplate
The 26.2 Step Mini Marathon is an Omaha-based 501(c)(3) nonprofit (in formation) that raises
awareness of hereditary cancer risk and removes barriers to education and genetic testing.
Founded in 2016, it invites people to take 26.2 steps — not miles — in honor of someone
affected by cancer, so anyone can take part regardless of ability.

Media contact
contact@262minimarathon.com  ·  262minimarathon.com
Facebook / Instagram @26.2stepminimarathon  ·  X @262stepminimar1

Note: A higher-resolution / vector logo and additional event photos will be added to this kit.
